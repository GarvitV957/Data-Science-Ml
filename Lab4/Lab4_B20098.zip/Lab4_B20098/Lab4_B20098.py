'''
Name: Garvit Verma
Roll no.: B20098
Contact no.: 8272840777
'''
import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
from sklearn import neighbors
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix,accuracy_score

# Q1
df=pd.read_csv("SteelPlateFaults-2class.csv")
'''
df.head()
X_label=df['Class']
X=df.copy()
'''
X0=df[df['Class']==0]
X1=df[df['Class']==1]
X_label0=X0['Class']
X_label1=X1['Class']

[X_train0,X_test0,X_label_train0,X_label_test0]=train_test_split(X0,X_label0,test_size=.3,random_state=42,shuffle=True)
[X_train1,X_test1,X_label_train1,X_label_test1]=train_test_split(X1,X_label1,test_size=.3,random_state=42,shuffle=True)

X_train=pd.concat([X_train0,X_train1])
X_test=pd.concat([X_test0,X_test1])
X_label_train=X_train['Class']
X_label_test=X_test['Class']

#[X_train,X_test,X_label_train,X_label_test]=train_test_split(X,X_label,test_size=.3,random_state=42,shuffle=True)

# creating csv file
X_train.to_csv("SteelPlateFaults-train.csv")
X_test.to_csv("SteelPlateFaults-test.csv")

# drop class attribute
X_train=X_train.drop('Class',axis=1)
X_test=X_test.drop('Class',axis=1)

# Defining KNN method
h_acc_K=1
h_acc_value=0
def KNN_q1(K):
    global h_acc_K
    global h_acc_value
    ne=KNeighborsClassifier(n_neighbors=K)
    ne.fit(X_train,X_label_train)
    X_label_predict=ne.predict(X_test)

    # Confusion matrix
    print("Confusion matrix for K: ",K)
    c_matrix=confusion_matrix(X_label_test.to_numpy(),X_label_predict)
    print(c_matrix)

    # accuracy_score
    acc=accuracy_score(X_label_test.to_numpy(),X_label_predict)
    print("Classification Accuracy for K: ",K," is ",acc)
    #finding highest accuracy
    if(acc>h_acc_value):
        h_acc_K=K
        h_acc_value=acc
        
KNN_q1(1)
KNN_q1(3)
KNN_q1(5)
print("Highest Accuracy Value is: ",h_acc_value," for K: ",h_acc_K)

# Q2
mini=X_train.min()
maxi=X_train.max()
diff=maxi-mini
df1_train=pd.DataFrame()
df2_test=pd.DataFrame()

for col in X_train:
        df1_train[col]=(X_train[col]-mini[col])/diff[col]
    
for col in X_test:
        df2_test[col]=(X_test[col]-mini[col])/diff[col]
    
# Creating csv file
df1_train.to_csv("SteelPlateFaults-train-Normalised.csv")
df2_test.to_csv("SteelPlateFaults-test-Normalised.csv")

# Defining KNN method
h_acc_K_q2=1
h_acc_value_q2=0
def KNN_q2(K):
    global h_acc_K_q2
    global h_acc_value_q2
    ne=KNeighborsClassifier(n_neighbors=K)
    ne.fit(df1_train,X_label_train)
    X_label_predict=ne.predict(df2_test)

    # Confusion matrix
    print("Confusion matrix for K: ",K)
    c_matrix=confusion_matrix(X_label_test.to_numpy(),X_label_predict)
    print(c_matrix)

    # accuracy_score
    acc=accuracy_score(X_label_test.to_numpy(),X_label_predict)
    print("Classification Accuracy for K: ",K," is ",acc)
    #finding highest accuracy
    if(acc>h_acc_value_q2):
        h_acc_K_q2=K
        h_acc_value_q2=acc

KNN_q2(1)
KNN_q2(3)
KNN_q2(5)
print("Highest Accuracy Value is: ",h_acc_value_q2," for K: ",h_acc_K_q2)

# Q3
train=pd.read_csv("SteelPlateFaults-train.csv")
test=pd.read_csv("SteelPlateFaults-test.csv")
train=train[train.columns[1:]]
test=test[test.columns[1:]]
test=test[test.columns[:-1]]

train.drop(columns=['TypeOfSteel_A300','TypeOfSteel_A400'],inplace=True)
test.drop(columns=['TypeOfSteel_A300','TypeOfSteel_A400'],inplace=True)

train0=train[train["Class"]==0]
train1=train[train["Class"]==1]
x_train0=train0[train0.columns[:-1]]
x_train1=train1[train1.columns[:-1]]

cov0=np.cov(x_train0.T)
cov1=np.cov(x_train1.T)
mean0=np.mean(x_train0)
mean1=np.mean(x_train1)

#print(round(mean0,3))
#print(round(mean1,3))

def likelihood(xv,mv,cmat):
    mat= np.dot((xv-mv).T,np.linalg.inv(cmat))
    ins= -0.5*np.dot(mat,(xv-mv))
    ex=np.exp(ins)
    return (ex/((2*np.pi)**12.5 * (abs(np.linalg.det(cmat)))**.5))

prior0=len(train0)/len(train)
prior1=len(train1)/len(train)
pre=[]
for i,row in test.iterrows():
    p0=likelihood(row,mean0,cov0)*prior0
    p1=likelihood(row,mean1,cov1)*prior1
    if(p0>p1):
        pre.append(0)
    else:
        pre.append(1)

bayes_acc=accuracy_score(X_label_test,pre)
print("confusion matrix \n",confusion_matrix(X_label_test,pre))
print("Accuracy: ",bayes_acc)
print()

# Q4
print("For KNN: ",h_acc_value)
print("For KNN Normalised: ",h_acc_value_q2)
print("For Bayes Classifier: ",bayes_acc)
