'''
   Name: Garvit Verma
   Roll no.: B20098
   Contact no.: 8272840777
'''

import pandas as pd 
from sklearn.mixture import GaussianMixture
from sklearn.metrics import confusion_matrix , accuracy_score
import operator
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

print('--------------------Part A------------------------------')
# Part A
# Q1 partA
train_data=pd.read_csv("SteelPlateFaults-train.csv")
test_data=pd.read_csv("SteelPlateFaults-test.csv")

train_data=train_data.drop(columns=['Unname','X_Minimum','Y_Minimum','TypeOfSteel_A300','TypeOfSteel_A400'])
test_data=test_data.drop(columns=['Unname','X_Minimum','Y_Minimum','TypeOfSteel_A300','TypeOfSteel_A400'])

train_0=train_data[train_data['Class']==0]
test_0=test_data[test_data['Class']==0]
train_1=train_data[train_data['Class']==1]
test_1=test_data[test_data['Class']==1]

train_0=train_0.drop(columns=['Class'])
train_1=train_1.drop(columns=['Class'])
test_0=test_0.drop(columns=['Class'])
test_1=test_1.drop(columns=['Class'])

max_acc=0
max_acc_q=2
q_list=[2,4,8,16]
for q in q_list:
    gmm_0 = GaussianMixture(n_components=q,covariance_type='full',reg_covar=1e-4)
    gmm_0.fit(train_0)
    gmm_1 = GaussianMixture(n_components=q,covariance_type='full',reg_covar=1e-4)
    gmm_1.fit(train_1)
    y0=gmm_0.score_samples(test_data.iloc[:,:23])
    y1=gmm_1.score_samples(test_data.iloc[:,:23])
    pred=[]
    for i in range(len(y1)):
        if y0[i]>y1[i]:
            pred.append(0)
        else:
            pred.append(1)
    mat = confusion_matrix(test_data['Class'],pred)
    acc=  accuracy_score(test_data['Class'],pred)
    print('This is the accuracy for the data predicted for ',q,' components :', round(acc,3))
    if(acc>max_acc):
        max_acc=acc
        max_acc_q=q
    print(mat)
    print()
print("Highest accuracy is: ",max_acc," for q: ",max_acc_q)
print()

# Q2 part A
# first three accuracies are calculated in lab4
print("Accuracy for KNN classifier: 89.614")
print("Accuracy for KNN classifier on Normalised data: 97.329")
print("Accuracy for Bayes classifier: 94.658")
print("Accuracy for Bayes classifier using GMM: ",round(max_acc*100,3))
print()

print('--------------------Part B-------------------')
# Part B
df=pd.read_csv('abalone.csv')
training_data,testing_data = train_test_split(df, test_size=0.3, random_state=42, shuffle=True)
training_data.to_csv('abalone-train.csv')
testing_data.to_csv('abalone-test.csv') 

corr_mat=df.corr()
#print(corr_mat)

'''
By correlation matrix, we can see the attribute which has the
highest Pearson correlation coefficient with the target attribute Rings is attribute "Shell weight".
'''

def linear_rgg(x_train,y_train,x_test,y_test,val):        #for linear regression
    x_train=pd.DataFrame(x_train)
    y_train=pd.DataFrame(y_train)
    x_test=pd.DataFrame(x_test)
    y_test=pd.DataFrame(y_test)
    lr=LinearRegression()
    data_model=lr.fit(x_train,y_train)
    if val==0:
        pred=data_model.predict(x_train)
    elif val==1:
        pred=data_model.predict(x_test)
    pred_list=[]
    for i in range(len(pred)):
        pred_list.append(pred[i][0])
    return(pred_list)

def non_linear_rgg(x_train,y_train,x_test,y_test,p,val):       #for non-linear regression
    x_train=np.array(x_train)[:, np.newaxis]
    y_train=np.array(y_train)[:, np.newaxis]
    x_test=np.array(x_test)[:, np.newaxis]
    y_test=np.array(y_test)[:, np.newaxis]
    poly_features = PolynomialFeatures(degree=p)
    x_poly = poly_features.fit_transform(x_train)
    regressor = LinearRegression()
    regressor.fit(x_poly, y_train)
    if val==0:
        pred = regressor.predict(poly_features.fit_transform(x_train))
    elif val==1:
        pred = regressor.predict(poly_features.fit_transform(x_test))
    #return pred
    pred_list=[]
    for i in range(len(pred)):
        pred_list.append(pred[i][0])
    return(pred_list)

def mul_non_linear_rgg(x_train,y_train,x_test,y_test,p,val):   #for multivariate non-linear regression
    poly_features = PolynomialFeatures(degree=p)
    x_poly = poly_features.fit_transform(x_train)
    regressor = LinearRegression()
    regressor.fit(x_poly, y_train)
    if val==0:
        pred = regressor.predict(x_poly)
    elif val==1:
        pred = regressor.predict(poly_features.fit_transform(x_test))
    return pred

def root_mean_squared_error(x,y):           #Root mean squared error
    rmse=0
    x=np.array(x)
    y=np.array(y)
    for i in range(len(x)):
        rmse+=(x[i]-y[i])**2
    return ((rmse/len(x))**0.5)

# Q1
print("---PART B-Q1---")
# part a
plt.scatter(training_data['Shell weight'],training_data['Rings'], label="Actual rings")
plt.title("For training data")
plt.xlabel("Shell weight")
plt.ylabel("Rings")
plt.plot(training_data['Shell weight'], linear_rgg(training_data['Shell weight'],training_data['Rings'],testing_data['Shell weight'],testing_data['Rings'],0), color ='red', label='Predicted rings')
plt.legend()
plt.show()

# part b
print("Prediction accuracy on training data: ", root_mean_squared_error(training_data['Rings'],linear_rgg(training_data['Shell weight'],training_data['Rings'],testing_data['Shell weight'],testing_data['Rings'],0)))

# part c
print("Prediction accuracy on testing data: ", root_mean_squared_error(testing_data['Rings'],linear_rgg(training_data['Shell weight'],training_data['Rings'],testing_data['Shell weight'],testing_data['Rings'],1)))

# part d
plt.scatter(testing_data['Rings'],linear_rgg(training_data['Shell weight'],training_data['Rings'],testing_data['Shell weight'],testing_data['Rings'],1))
plt.title("For testing data")
plt.xlabel('Actual Rings')
plt.ylabel('Predicted Rings')
plt.show()

# Q2
print("---PART B-Q2----")
# part a
print("Prediction accuracy on training data: ",root_mean_squared_error(training_data['Rings'],linear_rgg(training_data.iloc[:,0:7],training_data['Rings'],testing_data.iloc[:,0:7],testing_data['Rings'],0)))

# part b
print("Prediction accuracy on testing data: ",root_mean_squared_error(testing_data['Rings'],linear_rgg(training_data.iloc[:,0:7],training_data['Rings'],testing_data.iloc[:,0:7],testing_data['Rings'],1)))

# part c
plt.scatter(testing_data['Rings'],linear_rgg(training_data.iloc[:,0:7],training_data['Rings'],testing_data.iloc[:,0:7],testing_data['Rings'],1))
plt.title("For testing data")
plt.xlabel('Actual Rings')
plt.ylabel('Predicted Rings')
plt.show()

# Q3
print("---PART B-Q3---")
p=[2,3,4,5]

# part a
rmse_train=[]
for i in p:
    pred=non_linear_rgg(training_data['Shell weight'],training_data['Rings'],testing_data['Shell weight'],testing_data['Rings'],i,0)
    rmse_train.append(root_mean_squared_error(np.array(training_data['Rings']), pred))
    
print("Prediction accuracy on training data for p=2,3,4,5 are: ", rmse_train)
plt.bar(p,rmse_train)
plt.xlabel("Degree of the polynomial")
plt.ylabel("RMSE")
plt.title("For training data")
plt.show()

# part b
rmse_test=[]
for i in p:
    pred=non_linear_rgg(training_data['Shell weight'],training_data['Rings'],testing_data['Shell weight'],testing_data['Rings'],i,1)
    rmse_test.append(root_mean_squared_error(np.array(testing_data['Rings']), pred))

print("Prediction accuracy on testing data for p=2,3,4,5 are: ", rmse_test)
plt.bar(p,rmse_test)
plt.xlabel("Degree of the polynomial")
plt.ylabel("RMSE")
plt.title("For testing data")
plt.show()

# part c
# RMSE for training data is minimum for p=5
pred_train=non_linear_rgg(training_data['Shell weight'],training_data['Rings'],testing_data['Shell weight'],testing_data['Rings'],5,0)
plt.scatter(training_data['Shell weight'],training_data['Rings'], label="Actual rings")
sort_axis = operator.itemgetter(0)
sorted_zip = sorted(zip(training_data['Shell weight'],pred_train), key=sort_axis)
x, y_poly_pred = zip(*sorted_zip)
plt.plot(x, y_poly_pred, color='red', label="Predicted rings")
plt.title("For Training data")
plt.xlabel("Shell weight")
plt.ylabel("Rings")
plt.legend()
plt.show()

# part d
# RMSE for testing data is minimum for p=4
pred_test=non_linear_rgg(training_data['Shell weight'],training_data['Rings'],testing_data['Shell weight'],testing_data['Rings'],4,1)
plt.scatter(testing_data['Rings'], pred_test)
plt.title("For testing data")
plt.xlabel("Actual rings")
plt.ylabel("Predicted rings")
plt.show()

# Q4
print("---PART B-Q4---")
# part a
rmse_train=[]
P=[2,3,4,5]
for p in P:
    pred=mul_non_linear_rgg(training_data.iloc[:,0:7],training_data['Rings'],testing_data.iloc[:,0:7],testing_data['Rings'],p,0)
    rmse_train.append(root_mean_squared_error(np.array(training_data['Rings']), pred))
print("Prediction accuracy on training data for p=2,3,4,5 are: ", rmse_train)
plt.bar(P, rmse_train)
plt.xlabel("Degree of the polynomial")
plt.ylabel("RMSE")
plt.title("For training data")
plt.show()

# part b
rmse_test=[]
for p in P:
    pred=mul_non_linear_rgg(training_data.iloc[:,0:7],training_data['Rings'],testing_data.iloc[:,0:7],testing_data['Rings'],p,1)
    rmse_test.append(root_mean_squared_error(np.array(testing_data['Rings']), pred))
print("Prediction accuracy on testing data for p=2,3,4,5 are: ", rmse_test)
plt.bar(P, rmse_test)
plt.xlabel("Degree of the polynomial")
plt.ylabel("RMSE")
plt.title("For testing data")
plt.show()

# part c
# RMSE value for testing data is minimum for p=2:
pred_test=mul_non_linear_rgg(training_data.iloc[:,0:7],training_data['Rings'],testing_data.iloc[:,0:7],testing_data['Rings'],2,1)
plt.scatter(testing_data['Rings'], pred_test)
plt.title("For testing data")
plt.xlabel("Actual rings")
plt.ylabel("Predicted rings")
plt.show()